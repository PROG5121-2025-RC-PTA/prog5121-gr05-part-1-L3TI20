/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.poe;

import java.util.Scanner;
import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 *
 * @author RC_Student_lab
 */
public class POE {
    // Fixed arrays - they were incorrectly declared
    static String[] cell = new String[6];
    static String[] userN = new String[6];
    static String[] pass = new String[6];
    static int num = 0;
    
    // Validator class for checking username, password, and phone number
    public static class Validator{
        // Method to validate username
        public boolean checkUserName(String username) {
            // Check if the username contains underscore and is between 1 and 5 characters
            return username.length() <= 5 && username.contains("_");
        }

        // Method to validate password
        public boolean checkPassword(String password) {
            // Check if the password has at least 8 characters, contains an uppercase letter, a number, and a special character
            return password.length() >= 8 &&
                   password.matches(".*[A-Z].*") &&
                   password.matches(".*[0-9].*") &&
                   password.matches(".*[!@#$%^&+=].*");
        }

        // Method to validate South African cell phone number
        public boolean checkCellPhoneNumber(String cellPhoneNumber) {
            // South African cell phones typically start with '0' and contain 10 digits
            return cellPhoneNumber.matches("^[0-9]{10}$");
        }
    }
    
    // Login form class
    public static class LoginBox {

        /**
         *
         */
        public static void displayLoginForm() {
            // Create the frame
            JFrame frame = new JFrame("Register to KING MONADA");
            frame.setSize(350, 200);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(null);

            // Username Label and TextField
            JLabel userLabel = new JLabel("Username:");
            userLabel.setBounds(30, 30, 80, 25);
            frame.add(userLabel);

            JTextField userText = new JTextField();
            userText.setBounds(120, 30, 160, 25);
            frame.add(userText);

            // Password Label and PasswordField
            JLabel passLabel = new JLabel("Password:");
            passLabel.setBounds(30, 70, 80, 25);
            frame.add(passLabel);

            JPasswordField passText = new JPasswordField();
            passText.setBounds(120, 70, 160, 25);
            frame.add(passText);

            // Login Button
            JButton loginButton = new JButton("Login");
            loginButton.setBounds(120, 110, 160, 25);
            frame.add(loginButton);

            // Action listener for the login button
            loginButton.addActionListener((ActionEvent e) -> {
                String username = userText.getText();
                String password = new String(passText.getPassword());
                
                // Simple check (replace with real authentication logic)
                if (username.equals("admin") && password.equals("password")) {
                    JOptionPane.showMessageDialog(frame, "Welcome, User! It is great to see you again");
                } else {
                    JOptionPane.showMessageDialog(frame, "Username or password incorrect, please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            // Show the frame
            frame.setVisible(true);
        }
    }
    
    // Console Registration class
    public static class ConsoleRegistration {
        public static void startRegistration() {
            Scanner scanner = new Scanner(System.in);
            Validator validator = new Validator();
            
            // Validate the username
            String username;
            while (true) {
                System.out.print("Enter your username (it must contain an underscore and no more than five characters): ");
                username = scanner.nextLine();
                
                if (validator.checkUserName(username)) {
                    System.out.println("Username successfully captured");
                    break;
                } else {
                    System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
                }
            }
            
            // Validate the password
            String password;
            while (true) {
                System.out.print("Enter your password (it must have eight characters with a capital case, number and special character): ");
                password = scanner.nextLine();
                
                if (validator.checkPassword(password)) {
                    System.out.println("Password successfully captured");
                    break;
                } else {
                    System.out.println("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
                }
            }
            
            // Validate the cell phone number
            String cellPhoneNumber;
            while (true) {
                System.out.print("Enter your South African cell phone number (10 digits): ");
                cellPhoneNumber = scanner.nextLine();
                if (validator.checkCellPhoneNumber(cellPhoneNumber)) {
                    System.out.println("Cell phone number successfully captured");
                    break;
                } else {
                    System.out.println("Cell phone number incorrectly formatted or does not contain 10 digits.");
                }
            }
            
            // Thank the user and display the entered data
            System.out.println("\nThank you for providing the information.");
            System.out.println("Username: " + username);
            System.out.println("Password: " + password);
            System.out.println("Phone number: " + cellPhoneNumber);
            
            // Store the user information
            userN[num] = username;
            pass[num] = password;
            cell[num] = cellPhoneNumber;
            num++;
        }
    }
    
    // Main method
    public static void main(String[] args) {
        // You can choose which interface to display
        // For console-based registration:
        ConsoleRegistration.startRegistration();
        
        // For GUI-based login form:
        // LoginBox.displayLoginForm();
    }
}