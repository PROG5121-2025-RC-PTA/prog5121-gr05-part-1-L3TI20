/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.poe;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class NewMain { 
// Validator class for checking username, password, and phone number
    public static class Validator {
        // Method to val username
        public boolean checkUserName(String username) {
            // Check if the username contains underscore and is between 1 and 5 characters
            return username.length() <= 5 && username.contains("_");
        }
     // Method to check password
        public boolean checkPassword(String password) {
            // Check if the password has at least 8 characters, contains an uppercase letter, a number, and a special character
            return password.length() >= 8 &&
                   password.matches(".*[A-Z].*") &&
                   password.matches(".*[0-9].*") &&
                   password.matches(".*[!@#$%^&+=].*");
        }
         // Method to check South African cell phone number
        public boolean checkCellPhoneNumber(String cellPhoneNumber) {
            // South African cell phones typically start with '+27' and contain 10 digits
            return cellPhoneNumber.matches("^[0-9]{10}$");
        }
    }
    // Guided by chatgpt
    public static class ConsoleRegistration {
        public static void startRegistration(String password) {
            Scanner scanner = new Scanner(System.in);
            Validator validator = new Validator();
            
           // Guided by youtube and chatgpt 
            String username;
            while (true) {
                System.out.print("Enter your username (it must contain an underscore and no more than five characters): ");
                username = scanner.nextLine();
                
                if (validator.checkUserName(username)) {
                    System.out.println("Username successfully captured");
                    break;
                } else {
                    System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
                }
            } 
        
            // Validate the cell phone number
            String cellPhoneNumber;
            while (true) {
                System.out.print("Enter your South African cell phone number (10 digits): ");
                cellPhoneNumber = scanner.nextLine();
                if (validator.checkCellPhoneNumber(cellPhoneNumber)) {
                    System.out.println("Cell phone number successfully captured");
                    break;
                } else {
                    System.out.println("Cell phone number incorrectly formatted or does not contain 10 digits.");
                }
                }          
            
        }      
       
 