/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication6;

/**
 *
 * @author RC_Student_lab
 */
import java.util.*;
import javax.swing.JOptionPane;

class Message {

    static int returnTotalMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private final String messageID;
    private final int numMessagesSent;
    private final String recipient;
    private final String message;
    private final String messageHash;
    private static int totalMessages = 0;
    private static final List<Message> allMessages = new ArrayList<>();
    
    // Constructor
    public Message(String recipient, String message) {
        this.messageID = generateMessageID();
        this.numMessagesSent = ++totalMessages;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }
    
    // Generate random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }
    
    // Method to check if message ID is not more than 10 characters
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }
    
    // Method to check if recipient cell number is valid
    public int checkRecipientCell() {
        if (recipient != null && recipient.length() <= 10 && recipient.startsWith("+")) {
            return recipient.length();
        }
        return -1; // Invalid
    }
    
    // Method to create and return message hash
    public final String createMessageHash() {
        if (messageID.length() >= 2 && message.length() > 0) {
            String[] words = message.trim().split("\\s+");
            String firstWord = words[0];
            String lastWord = words[words.length - 1];
            
            String hash = messageID.substring(0, 2) + ":" + numMessagesSent + ":" + 
                         firstWord.toUpperCase() + lastWord.toUpperCase();
            return hash;
        }
        return "00:0:DEFAULTDEFAULT";
    }
    
    // Method to handle sending message with user choice
    public String sentMessage() {
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(null,
            "Choose an option for your message:",
            "Message Options",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
            
        switch (choice) {
            case 0 -> {
                allMessages.add(this);
                return "Message sent successfully!";
            }
            case 1 -> {
                return "Message discarded.";
            }
            case 2 -> {
                return "Message stored for later.";
            }
            default -> {
                return "No option selected.";
            }
        }
    }
    
    // Method to return list of all messages sent
    public static String printMessages() {
        if (allMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        
        StringBuilder result = new StringBuilder();
        result.append("=== ALL SENT MESSAGES ===\n");
        result.append("Total messages sent: ").append(allMessages.size()).append("\n\n");
        
        for (Message msg : allMessages) {
            result.append("Message ID: ").append(msg.messageID).append("\n");
            result.append("Message Hash: ").append(msg.messageHash).append("\n");
            result.append("Recipient: ").append(msg.recipient).append("\n");
            result.append("Message: ").append(msg.message).append("\n");
            result.append("-------------------\n");
        }
        
        return result.toString();
    }
    
    // Getters
    public String getMessageID() { return messageID; }
    public int getNumMessagesSent() { return numMessagesSent; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
    public static int getTotalMessages() { return totalMessages; }
}

public class QuickChatApp {
    private static boolean isLoggedIn = false;
    private static int maxMessages = 0;
    private static int messagesSent = 0;
    
    public static void main(String[] args) {
        // Display welcome message
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        
        // Get number of messages user wants to send
        String input = JOptionPane.showInputDialog("How many messages do you want to send?");
        try {
            maxMessages = Integer.parseInt(input);
            if (maxMessages <= 0) {
                JOptionPane.showMessageDialog(null, "Invalid number. Exiting.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Exiting.");
            return;
        }
        
        // Login requirement
        if (!login()) {
            JOptionPane.showMessageDialog(null, "Login failed. You cannot send messages.");
            return;
        }
        
        // Main application loop
        boolean running = true;
        while (running && messagesSent < maxMessages) {
            String[] menuOptions = {
                "1) Send Messages",
                "2) Show recently sent messages",
                "3) Quit"
            };
            
            String choice = (String) JOptionPane.showInputDialog(null,
                "Choose an option:",
                "QuickChat Menu",
                JOptionPane.QUESTION_MESSAGE,
                null,
                menuOptions,
                menuOptions[0]);
                
            if (choice == null) {
                running = false;
                continue;
            }
            
            switch (choice.charAt(0)) {
                case '1' -> {
                    if (messagesSent < maxMessages) {
                        sendMessage();
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "You have reached your message limit of " + maxMessages);
                    }
                }
                case '2' -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                case '3' -> running = false;
                default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
        
        // Display final message count
        JOptionPane.showMessageDialog(null, 
            "Total messages sent: " + Message.getTotalMessages());
        
        // Show all messages
        if (Message.getTotalMessages() > 0) {
            JOptionPane.showMessageDialog(null, Message.printMessages());
        }
        
        JOptionPane.showMessageDialog(null, "Thank you for using QuickChat!");
    }
    
   private static boolean login() {
    String username = JOptionPane.showInputDialog("Enter username:");
    String password = JOptionPane.showInputDialog("Enter password:");

    if (username == null || password == null) {
        JOptionPane.showMessageDialog(null, "Username or password cannot be null.");
        return false;
    }

    // Username validation: max 5 characters and contains '_'
    if (username.length() > 5 || !username.contains("_")) {
        JOptionPane.showMessageDialog(null, "Username must be at most 5 characters and contain an underscore.");
        return false;
    }

    // Password validation
    String passwordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*+])(?=\\S+$).{8,20}$";

    if (!password.matches(passwordPattern)) {
        JOptionPane.showMessageDialog(null, "Password must be 8-20 characters long, include uppercase and lowercase letters, a digit, a special character (!@#$%^&*+), and contain no spaces.");
        return false;
    }

    isLoggedIn = true;
    JOptionPane.showMessageDialog(null, "Login successful!");
    return true;
}

    
    private static void sendMessage() {
        if (!isLoggedIn) {
            JOptionPane.showMessageDialog(null, "You must be logged in to send messages.");
            return;
        }
        
        // Get recipient
        String recipient;
        while (true) {
            recipient = JOptionPane.showInputDialog("Enter recipient's cell number +27 : ");
            if (recipient == null) return;
            
            if (recipient.startsWith("+27") && recipient.length() <= 10) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, 
                    "Invalid recipient number. Must start with + and be max 10 characters.");
            }
        }
        
        // Get message
        String messageText;
        while (true) {
            messageText = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
            if (messageText == null) return; // User cancelled
            
            if (messageText.length() > 250) {
                JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
            } else if (messageText.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a message of less than 50 characters.");
            } else if (messageText.trim().length() > 0) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Message cannot be empty.");
            }
        }
        
        // Create message object
        Message msg = new Message(recipient, messageText);
        
        // Display message details
        String details = """
                         Message Details:
                         Message ID: """ + msg.getMessageID() + "\n" +
                        "Message Hash: " + msg.getMessageHash() + "\n" +
                        "Recipient: " + msg.getRecipient() + "\n" +
                        "Message: " + msg.getMessage();
        
        JOptionPane.showMessageDialog(null, details);
        
        // Handle sending
        String result = msg.sentMessage();
        JOptionPane.showMessageDialog(null, result);
        
        if (result.contains("sent successfully")) {
            messagesSent++;
            JOptionPane.showMessageDialog(null, "Message sent! (" + messagesSent + "/" + maxMessages + ")");
        }
    }
}
