/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package javaapplication6;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testCheckMessageID_ValidLength() {
        Message msg = new Message("+27834557896", "Did you get the cake?");
        assertTrue(msg.checkMessageID(), "Message ID should be 10 characters or fewer.");
    }

    @Test
    public void testCheckRecipientCell_ValidInternationalFormat() {
        Message msg = new Message("+27834557896", "Hello!");
        assertEquals(1, msg.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_ValidNumeric() {
        Message msg = new Message("0838884567", "Hi there!");
        assertEquals(1, msg.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_Invalid() {
        Message msg = new Message("abcd123", "Invalid number");
        assertEquals(0, msg.checkRecipientCell());
    }

    @Test
    public void testCreateMessageHash_Format() {
        Message msg = new Message("+27838884567", "Where are you?");
        String hash = msg.getMessageHash();
        assertNotNull(hash);
        assertTrue(hash.matches("[A-Z0-9]{2}:\\d+:\\w+:\\w+"),
            "Hash should match format: XX:#:firstWord:lastWord");
    }

    @Test
    public void testCreateMessageHash_FirstAndLastWord() {
        Message msg = new Message("+27834484567", "Yohoooo, I am at your gate.");
        String hash = msg.getMessageHash();
        assertTrue(hash.contains("YOHOOOO,") && hash.contains("GATE."), "Hash must contain first and last word");
    }

    @Test
    public void testReturnTotalMessages_Increments() {
        int initial = Message.returnTotalMessages();
        Message msg = new Message("+27834557896", "Test message");
        msg.SentMessage(); 
        assertTrue(Message.returnTotalMessages() >= initial);
    }
}
